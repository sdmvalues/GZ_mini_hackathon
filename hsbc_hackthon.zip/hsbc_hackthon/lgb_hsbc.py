import lightgbm as lgb
import numpy as np
import pickle
import pandas as pd

df = pd.read_csv('train.csv')



def get_target_and_features(cust_id):
    sel = df.loc[df.ID==cust_id].drop('ID', axis=1)
    target = sel['target'].values
    features = sel.drop('target', axis=1).values
    return target, features


def get_prediction(cust_id):
    with open('lgb.pickle','rb') as f:
        lgb = pickle.load(f)
        # cust_id = input("plaese input cust ID: ")
        tar, features = get_target_and_features(cust_id)
        predict_target = int(np.expm1(lgb.predict(features)))
        true_target = tar[0]
        return predict_target, true_target
        # print("Predict Target of cust {} is {}, the true target is {}".format(cust_id, predict_target, true_target))